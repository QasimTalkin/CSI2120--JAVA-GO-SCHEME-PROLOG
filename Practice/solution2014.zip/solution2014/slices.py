animals = ['giraffe', 'tiger', 'monkey', 'mouse']

print(animals[0:2])
print(animals[0:3])
print(animals[0:])
print(animals[:])
print(animals[1:])
print(animals[1:-1])